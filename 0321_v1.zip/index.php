<?php
    header('location:login.php');
?>

<html>
    <head>
        <title>正在重導向中……</title>
    </head>
</html>